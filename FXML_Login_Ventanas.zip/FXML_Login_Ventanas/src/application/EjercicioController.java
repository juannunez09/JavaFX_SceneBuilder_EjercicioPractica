package application;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class EjercicioController {
	public Label lblsalida;
	public TextField txtentrada ;
	
	public void Salida() {
		System.out.println("-- Funcion cambiar --");
		String cambio = txtentrada.getText().toString();
		lblsalida.setText(cambio);
	}
	
	
}
