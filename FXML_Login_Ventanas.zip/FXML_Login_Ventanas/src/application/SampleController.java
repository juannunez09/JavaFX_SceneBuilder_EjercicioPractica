package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class SampleController {
		
		String password = "123456";
		public PasswordField inputpassword;
		public void login(ActionEvent event) {

			if(inputpassword.getText().equals(password)) {
				GridPane root;
				try {
					root = (GridPane)FXMLLoader.load(getClass().getResource("Ejercicio.fxml"));
					Scene scene = new Scene(root,400,400);
					scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
					Stage secondaryStage = new Stage();
					secondaryStage.setScene(scene);
					secondaryStage.show();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}else {
				System.out.println("Contrase�a MAL ESCRITA");
			}
		}
	}
